// JavaScript
// src/firebase.js
// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional

import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

// TODO: Replace the following with your app's Firebase project configuration
// See: https://firebase.google.com/docs/web/learn-more#config-object
const firebaseConfig = {
  // ...

  apiKey: "AIzaSyBpZMDlLFRZamJIERHodutvm1EE49Y3-GA",
  authDomain: "be-africa-awards-496ae.firebaseapp.com",
  projectId: "be-africa-awards-496ae",
  storageBucket: "be-africa-awards-496ae.appspot.com",
  messagingSenderId: "119371661659",
  appId: "1:119371661659:web:51b1f45cfc5b41ca12da7e",
  measurementId: "G-6NL89BDK4W"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firebase Authentication and get a reference to the service
export const auth = getAuth(app);
export const db = getFirestore(app);
export default app;

import "./styles.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./routes/Home";
import Voting from "./routes/Voting";
import Vote from "./routes/Vote";
import Sponsorship from "./routes/Sponsorship";
import About from "./routes/About";
import Contact from "./routes/Contact";
import Gallery from "./routes/Gallery";
import GalleryMore from "./routes/GalleryMore";
import Buy from "./routes/Buy";

function BeAfricaAwards() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/voting" element={<Voting />} />
        <Route path="/sponsorship" element={<Sponsorship />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/gallery/pictures" element={<GalleryMore />} />
        <Route path="/voting/process" element={<Vote />} />
        <Route path="/voting/buy" element={<Buy />} />
      </Routes>
    </BrowserRouter>
  );
}
export default BeAfricaAwards;

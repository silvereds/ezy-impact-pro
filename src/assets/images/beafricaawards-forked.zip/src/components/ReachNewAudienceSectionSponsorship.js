import "./ReachNewAudienceSectionSponsorshipStyles.css";
const ReachNewAudienceSectionSponsorship = () => {
  return (
    <div className="reach-new-audience">
      <div className="reach-new-audience-section secondary-background">
        <p className="reach-new-audience-title-white">Reach New Audience</p>
        <p className="reach-new-audience-infos-white">
          BE AFRICA AWARDS might be the opportunity you need to shine in front
          of your target. Tap into the event opportunities that resonate with
          your niche to expand your brand’s exposure.
        </p>
      </div>
      <div className="reach-new-audience-section third-background">
        <p className="reach-new-audience-title-gray">
          Increase Your Market Share
        </p>
        <p className="reach-new-audience-infos-gray">
          By sponsoring BE AFRICA AWARDS, you get to meet potential clients
          during the event and benefit from our advertising program.
        </p>
      </div>
      <div className="reach-new-audience-section secondary-background">
        <p className="reach-new-audience-title-white">Social Empowering</p>
        <p className="reach-new-audience-infos-white">
          An agreement between you and us is not just a money-making deal. It is
          also about matching two visions and crafting a message for the big
          community. Thus you get to share your core values.
        </p>
      </div>
    </div>
  );
};
export default ReachNewAudienceSectionSponsorship;

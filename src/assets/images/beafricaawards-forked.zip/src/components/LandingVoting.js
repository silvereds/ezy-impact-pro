import "./LandingVotingStyles.css";
import Logo from "../assets/logo.png";

const LandingVoting = () => {
  return (
    <div class="landing-voting-landing">
      <div className="landing-voting-left">
        <p class="landing-voting-title-part-1">BE AFRICA </p>
        <p class="landing-voting-title-part-2">AWARDS VOTE 2023</p>
        <p className="landing-voting-infos-text roboto-light">
          This year votes are open. Below are 14 categories designed to
          acknowledge the talent, creativity, hard work, and excellence of our
          fellows in our communities. The votes go from... to …
          <br />
          <br />
          Do you want to know more about the upcoming Gala?
        </p>
        <p className="btn">Upcoming Gala</p>
      </div>
      <div className="landing-voting-image">
        <img className="landing-voting-right" src={Logo} alt="Awards" />
      </div>
    </div>
  );
};
export default LandingVoting;

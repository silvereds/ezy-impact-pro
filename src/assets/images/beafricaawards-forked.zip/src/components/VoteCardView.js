import "./VoteCardViewStyles.css";
import { HashLink } from "react-router-hash-link";
import React, { Component } from "react";

export var name_nominee = "hello";
export var id_nominee = "1";
export var id_category = "1";

class VoteCardView extends Component {
  passData() {
    var p = document.getElementById("name_of_nominee");
    name_nominee = p.textContent;
  }
  render() {
    var is_primary = true;
    if (this.props.Background !== "primary_bg") {
      is_primary = false;
    }
    return (
      <div className="vote-card-view border" id={this.props.Background}>
        <img
          className="vote-card-image"
          src={this.props.Nominee}
          alt="Trophy"
        />
        <div className="vote-card-padding">
          <p
            className={
              is_primary ? "vote-card-count border" : "vote-card-count-1 border"
            }
          >
            {this.props.Count}
          </p>
          <p id="name_of_nominee" className="vote-card-title">
            {this.props.Name}
          </p>
          <p className="vote-card-infos">{this.props.Description}</p>
          <div className="vote-card-buttons">
            <HashLink smooth to="/voting/process/#" className="hashlink">
              <p className="btn" onClick={this.passData}>
                Vote
              </p>
            </HashLink>

            <HashLink smooth to="/voting/buy/#" className="hashlink">
              <p className="btn-light">Buy</p>
            </HashLink>
          </div>
        </div>
      </div>
    );
  }
}
export default VoteCardView;

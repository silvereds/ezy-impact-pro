import "./GalleryVideosStyles.css";
import { Slide } from "react-slideshow-image";
import "react-slideshow-image/dist/styles.css";
import YoutubeEmbed from "./YoutubeEmbed";

const { Component } = require("react");

class GalleryVideos extends Component {
  render() {
    return (
      <div className="primary-background gallery-videos">
        <p className="vote-title secondary-title-color">SOME VIDEOS</p>
        <p className="vote-guidance primary-text-color video-infos">
          They show our works before and during our events. Please, watch some!
        </p>
        <div className="big-screen-video">
          <Slide>
            <div className="each-slide-video-section">
              <div className="size-video-slide">
                <YoutubeEmbed embedId="zRYvbySXeUs" />
              </div>
              <div className="size-video-slide">
                <YoutubeEmbed embedId="TQvhihN05RA" />
              </div>
            </div>
          </Slide>
        </div>
        <div className="small-screen-video">
          <Slide>
            <div className="each-slide-video-section">
              <div className="size-video-slide">
                <YoutubeEmbed embedId="zRYvbySXeUs" />
              </div>
            </div>
          </Slide>
        </div>
      </div>
    );
  }
}
export default GalleryVideos;

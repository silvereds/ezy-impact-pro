import "./SponsorshipGalaExposureStyles.css";
import Exposure from "../assets/gala_exposure.png";

const SponsorshipGalaExposure = () => {
  return (
    <div className="sponsorship-gala-exposure primary-background">
      <div className="gala-exposure-infos">
        <p className="gala-exposure-infos-title secondary-title-color">
          GALA EXPOSURE
        </p>
        <p className="gala-exposure-infos-text primary-text-color roboto-light">
          This is a room plan for the upcoming ceremony. It gives you an idea of
          the exposure you have as a sponsor.
        </p>
      </div>
      <img src={Exposure} alt="Gala-exposure" />
      <p className="btn-light">The upcoming Gala here</p>
    </div>
  );
};
export default SponsorshipGalaExposure;

import "./AboutSponsorshipStyles.css";
import Teamwork from "../assets/teamwork.png";

const AboutSponsorship = () => {
  return (
    <div className="about-sponsorship">
      <p className="secondary-background roboto-light primary-text-color about-purpose">
        We aim to <em>become leaders</em> in the domain. With our distinctive
        organizational platform, we strive to become a reference in award shows,
        Galas, business conferences, and so on.
      </p>
      <div className="about-sponsorship-bottom primary-background">
        <div className="about-sponsorship-bottom-left primary-block border">
          <img src={Teamwork} alt="Teamwork" />
        </div>
        <div className="about-sponsorship-bottom-right">
          <p className="fourth-text-color">What is it for?</p>
          <p className="secondary-title-color about-sponsorship-title">
            SPONSORSHIP
          </p>
          <p className="primary-text-color roboto-light about-sponsor-infos">
            BE AFRICA AWARDS is developing opportunities for companies willing
            to sponsor the initiative. This is a win-win partnership. Please,
            make sure you have a look at the benefits of such a deal down here.
          </p>
          <p className="btn" id="btn-benefit">
            Benefits of sponsorship
          </p>
        </div>
      </div>
    </div>
  );
};
export default AboutSponsorship;

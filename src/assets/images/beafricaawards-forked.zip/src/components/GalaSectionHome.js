import "./GalaSectionHomeStyles.css";
import YoutubeEmbed from "./YoutubeEmbed";
import { HashLink } from "react-router-hash-link";

const GalaSectionHome = () => {
  return (
    <div className="gala-home">
      <div className="gala-left">
        <p className="gala-title-part-1">GALA BE AFRICA</p>
        <p className="gala-title-part-2">AWARDS 2023</p>
        <p className="gala-infos-text roboto-light">
          This year’s gala will be held on the 28th of April In Guangzhou,
          China. Over 500 people are expected during the event. Here is what you
          can expect: <br />
          <br />
          * Artists performance
          <br />
          * Presentation of the winners
          <br />
          * Miss & Master Show
          <br />
          * Fashion Show
          <br />
          <br />
          * Countries' culture presentation
          <br />
          * Miss Guangzhou Pageant
          <br />
          * Sponsors presentation
          <br />* Auction Sales
        </p>
        <HashLink smooth to="/about/#" className="hashlink">
          <p className="btn">More about the awards</p>
        </HashLink>
      </div>
      <div className="gala-right">
        <YoutubeEmbed embedId="KsqUM-PAMXI" />
      </div>
    </div>
  );
};
export default GalaSectionHome;

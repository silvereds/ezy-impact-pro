import "./GalleryPicturesStyles.css";
import { HashLink } from "react-router-hash-link";
import Ig from "../assets/sponsor_.jpg";
import Ig1 from "../assets/sponsor_1.jpg";
import Ig2 from "../assets/sponsor_2.jpg";
import Ig3 from "../assets/sponsor_4.jpg";
import Ig4 from "../assets/sponsor_6.jpg";

const { Component } = require("react");

class GalleryPictures extends Component {
  render() {
    return (
      <div className="secondary-background gallery-pictures">
        <p className="vote-title secondary-title-color">SOME PICTURES</p>
        <p className="vote-guidance primary-text-color">
          Appreciate them with us. They are related to our activities.
        </p>
        <div className="pictures-box">
          <HashLink smooth to="/gallery/pictures/#" className="hash-link">
            <img src={Ig} alt="pic" id="img_1" className="border" />
          </HashLink>

          <HashLink smooth to="/gallery/pictures/#" className="hash-link">
            <img src={Ig1} alt="pic" id="img_2" className="border" />
          </HashLink>

          <HashLink smooth to="/gallery/pictures/#" className="hash-link">
            <img src={Ig2} alt="pic" id="img_3" className="border" />
          </HashLink>

          <HashLink smooth to="/gallery/pictures/#" className="hash-link">
            <img src={Ig3} alt="pic" id="img_4" className="border" />
          </HashLink>

          <HashLink smooth to="/gallery/pictures/#" className="hash-link hide">
            <img src={Ig4} alt="pic" id="img_5" className="border" />
          </HashLink>

          <HashLink smooth to="/gallery/pictures/#" className="hash-link hide">
            <img src={Ig3} alt="pic" id="img_6" className="border" />
          </HashLink>
        </div>
        <HashLink smooth to="/gallery/pictures/#" className="hashlink">
          <p className="btn-light-plus">See more</p>
        </HashLink>
      </div>
    );
  }
}
export default GalleryPictures;

import { Component } from "react";
import "./AboutTeamLeadCardViewStyles.css";
import {
  TbBrandFacebook,
  TbBrandYoutube,
  TbBrandTwitter,
  TbBrandInstagram
} from "react-icons/tb";

class AboutTeamLeadCardView extends Component {
  render() {
    return (
      <div className="team-lead-card secondary-background border">
        <img
          src={this.props.Picture_Team_Lead}
          alt="Team-lead"
          className="border"
        />
        <p className="secondary-title-color team-lead-name">
          {this.props.Name_Team_Lead}
        </p>
        <p className="secondary-text-color roboto-light team-lead-infos">
          {this.props.Small_Description_Team_Lead}
        </p>
        <ul>
          <li>
            <a href={this.props.F_link}>
              <TbBrandFacebook size={22} style={{ color: "#ffffff" }} />
            </a>
          </li>
          <li>
            <a href={this.props.Y_link}>
              <TbBrandYoutube size={22} style={{ color: "#ffffff" }} />
            </a>
          </li>
          <li>
            <a href={this.props.T_link}>
              <TbBrandTwitter size={22} style={{ color: "#ffffff" }} />
            </a>
          </li>
          <li>
            <a href={this.props.I_link}>
              <TbBrandInstagram size={22} style={{ color: "#ffffff" }} />
            </a>
          </li>
        </ul>
      </div>
    );
  }
}
export default AboutTeamLeadCardView;

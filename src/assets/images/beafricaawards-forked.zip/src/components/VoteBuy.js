import { Component } from "react";
import "./VoteBuyStyles.css";
import Qrcode from "../assets/qrcode.jpg";
import { HashLink } from "react-router-hash-link";

class VoteBuy extends Component {
  render() {
    return (
      <div className="vote-buy primary-background">
        <div className="back-buy border">
          <div className="buy-top">
            <div>
              <p className="secondary-title-color buy-title">BUY VOTES FOR</p>
              <p className="primary-text-color buy-infos roboto-light">
                1. To support your favorite, please, select a price (100, 300,
                500, or 1000 RMB).
                <br />
                <br />
                2. Scan the QRcode and buy to get the equivalent voices (100,
                300, 500, or 1000).
                <br /> <br />
                3. Screenshot the payment for proof..
                <br /> <br />
                4. Send us the screenshot. We will process it and confirm it to
                you
              </p>
            </div>
            <img src={Qrcode} alt="Qrcode" className="border" />
          </div>
          <div className="buy-bottom secondary-background border">
            <div className="buy-prices">
              <p className="btn-light-plus">100 RMB</p>
              <p className="btn-light-plus">300 RMB</p>
              <p className="btn-light-plus">500 RMB</p>
              <p className="btn-light-plus">1000 RMB</p>
            </div>
            <p className="btn" id="send_screenshot">
              Send the screenshot of the payment
            </p>
          </div>
        </div>
      </div>
    );
  }
}
export default VoteBuy;

import React, { useEffect, useState } from "react";
import "./VoteProcessStyles.css";
import "firebase/compat/auth";
import Google from "../assets/google_icon.png";
import Facebook from "../assets/facebook_icon.png";
import {
  GoogleAuthProvider,
  signInWithPopup,
  FacebookAuthProvider
} from "firebase/auth";
import { auth, db } from "../firebase_setup/firebase";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword
} from "firebase/auth";
import {
  Timestamp,
  collection,
  query,
  addDoc,
  where,
  getDocs
} from "firebase/firestore";
import { id_category, name_nominee, id_nominee } from "./VoteCardView";

export const dateWithoutHour = () => {
  const date = new Date();
  let newDate = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  return newDate;
};

function VoteProcess() {
  var id_user = "";
  const voice = 1;
  const price = 0;
  const status = true;

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  //Get the date
  const dmy = (date = new Date()) => {
    const d = new Date(date).getDate();
    const m = new Date(date).getMonth() + 1;
    const y = new Date(date).getFullYear();
    return d + "_" + m + "_" + y;
  };

  //function to check if the user has already voted for the day

  useEffect(() => {
    const checkVote = async (id_user) => {
      const id = id_user + dmy();
      const q = query(collection(db, "votes"), where("id_vote", "==", id));
      const docSnap = await getDocs(q);
      let canVote = true;

      docSnap.forEach((doc) => {
        canVote = false;
        alert("hey hey");
      });
      return canVote;
    };
    checkVote("tchofsilvere@gmail.com");
  }, []);

  //function to add a vote
  const addVote = async (e, id_user) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, "votes"), {
        id_vote: id_user + dmy(),
        id_user: id_user,
        id_nominee: id_nominee,
        id_category: id_category,
        voice: voice,
        price: price,
        status: status,
        created: Timestamp.now()
      });
    } catch (err) {
      alert(err);
    }
  };

  //Google Popup
  const HandleGoogle = async (e) => {
    const provider = await new GoogleAuthProvider();
    return signInWithPopup(auth, provider)
      .then(async (result) => {
        // This gives you a Google Access Token. You can use it to access the Google API.
        //const credential = GoogleAuthProvider.credentialFromResult(result);
        //const token = credential.accessToken;
        // The signed-in user info.
        const user = result.user;
        // IdP data available using getAdditionalUserInfo(result)
        // ...
        id_user = user.email;
        console.log(user);
        alert("Successfully Signed in!");
        //Add a vote if not yet voted for the day
        const canVote = await checkVote(id_user);
        console.log("can vote ", canVote);
        if (canVote) {
          addVote(e, id_user);
          alert("Voted successfully! Thank you for your support.");
        } else {
          alert("Sorry, you have already vote for today!");
        }
      })
      .catch((error) => {
        // Handle Errors here.
        const errorCode = error.code;
        //const errorMessage = error.message;
        // The email of the user's account used.
        //const email = error.customData.email;
        // The AuthCredential type that was used.
        //const credential = GoogleAuthProvider.credentialFromError(error);
        // ...
        alert(errorCode);
      });
  };

  //Facebook Popup
  const HandleFacebook = async (e) => {
    const provider = await new FacebookAuthProvider();
    return signInWithPopup(auth, provider)
      .then((result) => {
        // This gives you a Google Access Token. You can use it to access the Google API.
        //const credential = GoogleAuthProvider.credentialFromResult(result);
        //const token = credential.accessToken;
        // The signed-in user info.
        const user = result.user;
        // IdP data available using getAdditionalUserInfo(result)
        // ...
        console.log(user);
        alert("Successfully Signed in!");
        //Add a vote
        id_user = user.email;
        addVote(e, id_user);
        alert("Voted! Thank you for your support.");
      })
      .catch((error) => {
        // Handle Errors here.
        const errorCode = error.code;
        //const errorMessage = error.message;
        // The email of the user's account used.
        //const email = error.customData.email;
        // The AuthCredential type that was used.
        //const credential = GoogleAuthProvider.credentialFromError(error);
        // ...
        alert(errorCode);
      });
  };

  //Email & Password => Sign Up
  const signUp = (e) => {
    createUserWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        // Signed in
        const user = userCredential.user;
        console.log(user);
        alert("Successfully created an account");
        //Add a vote
        id_user = user.email;
        addVote(e, id_user);
        alert("Voted! Thank you for your support.");
      })
      .catch((error) => {
        const errorCode = error.code;
        //const errorMessage = error.message;
        // ..
        alert(errorCode);
      });
  };

  //Email & Password => Sign In
  const signIn = (e) => {
    signInWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        // Signed in
        const user = userCredential.user;
        console.log(user);
        alert("Successfully Signed in");
        //Add a vote
        id_user = user.email;
        addVote(e, id_user);
        alert("Voted! Thank you for your support.");
      })
      .catch((error) => {
        const errorMessage = error.message;
        alert(errorMessage);
      });
  };

  return (
    <div className=" voting-process primary-background ">
      <div className="vote-process border">
        <p className="secondary-title-color vote-title">{name_nominee}</p>
        <p className="primary-text-color vote-guidance">
          Sign in to vote for your favorite
        </p>
        <input
          onChange={(e) => setEmail(e.target.value)}
          type="email"
          placeholder="Your email address..."
          id="email_vote"
          name="email_vote"
          className="border textfields roboto-thin"
        />
        <input
          onChange={(e) => setPassword(e.target.value)}
          type="password"
          placeholder="Your password..."
          id="password"
          name="password"
          className="border textfields roboto-thin"
        />
        <div className="btn-sign">
          <p className="btn" id="sign_in_vote" onClick={signIn}>
            Sign In
          </p>
          <p className="btn-light" id="sign_up_vote" onClick={signUp}>
            Create
          </p>
        </div>

        <p className="secondary-title-color option">or</p>
        <div className="icons-section">
          <div className="bg border">
            <img
              src={Google}
              alt="Google"
              className="account-icon"
              onClick={HandleGoogle}
            />
          </div>

          <div className="bg border">
            <img
              src={Facebook}
              alt="Facebook"
              className="account-icon"
              onClick={HandleFacebook}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default VoteProcess;

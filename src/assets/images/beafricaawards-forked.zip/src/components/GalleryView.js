import { Component } from "react";
import "./GalleryViewStyles.css";

class GalleryView extends Component {
  render() {
    return (
      <div className="gallery-middle">
        <div className="gallery-middle-left">
          <img
            className="gallery-big-pic border"
            src={this.props.Big_Pic_1}
            alt="gallery"
          />
          <div className="gap-between small-pics">
            <div className="gallery-div-small-pic">
              <img
                className="gallery-small-pic border"
                src={this.props.Small_Pic_1}
                alt="gallery"
              />
              <img
                className="gallery-small-pic border"
                src={this.props.Small_Pic_2}
                alt="gallery"
              />
            </div>
            <div className="gallery-div-small-pic div-small-pic-bottom">
              <img
                className="gallery-small-pic border"
                src={this.props.Small_Pic_3}
                alt="gallery"
              />
              <img
                className="gallery-small-pic border"
                src={this.props.Small_Pic_4}
                alt="gallery"
              />
            </div>
          </div>
        </div>
        <div className="gallery-middle-right">
          <div className="small-pics">
            <div className="gallery-div-small-pic">
              <img
                className="gallery-small-pic border"
                src={this.props.Small_Pic_5}
                alt="gallery"
              />
              <img
                className="gallery-small-pic border"
                src={this.props.Small_Pic_6}
                alt="gallery"
              />
            </div>
            <div className="gallery-div-small-pic div-small-pic-bottom">
              <img
                className="gallery-small-pic border"
                src={this.props.Small_Pic_7}
                alt="gallery"
              />
              <img
                className="gallery-small-pic border"
                src={this.props.Small_Pic_8}
                alt="gallery"
              />
            </div>
          </div>
          <div className="gap-between">
            <img
              className="gallery-big-pic border"
              src={this.props.Big_Pic_2}
              alt="gallery"
            />
          </div>
        </div>
      </div>
    );
  }
}
export default GalleryView;

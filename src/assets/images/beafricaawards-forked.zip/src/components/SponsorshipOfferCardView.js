import { Component } from "react";
import "./SponsorshipOfferCardViewStyles.css";

class SponsorshipOfferCardView extends Component {
  render() {
    return (
      <div className="sponsorship-offer border">
        <div>
          <p className="sponsorship-offer-type">{this.props.Offer_Type}</p>
          <p className="sponsorship-offer-class">{this.props.Class}</p>
          <div className="sponsorship-offer-amount secondary-background border">
            <p>Support with {this.props.Amount} RMB</p>
          </div>
          <p className="sponsorship-offer-infos roboto-light">
            {this.props.Infos}
          </p>
          <p className="btn">Become</p>
        </div>
        <div className="sponsorship-offer-support-part border secondary-background">
          <p className="sponsorship-offer-support roboto-light">Support with</p>
          <p className="sponsorship-offer-support roboto-light">
            {this.props.Amount}
          </p>
          <p className="sponsorship-offer-support roboto-light">RMB</p>
        </div>
      </div>
    );
  }
}
export default SponsorshipOfferCardView;

import "./LandingGalleryStyles.css";
const { Component } = require("react");

class LandingGallery extends Component {
  render() {
    return (
      <div className="landing-gallery primary-background">
        <div>
          <p className="primary-title-color landing-gallery-title">
            BE AFRICA
            <br />
            AWARDS GALLERY
          </p>
          <p className="primary-text-color roboto-light landing-gallery-infos-text">
            Here are some pictures and videos related to BE AFRICA AWARDS event.
            Please, have a look and enjoy how beautiful they are.
            <br />
            <br />
            Do you know there is an upcoming event/Gala?
          </p>
          <p className="btn">Upcoming Gala</p>
        </div>
        <div className="landing-gallery-right">
          <div className="block-1">
            <img className="border" src={this.props.Photo_1} alt="Photo 1" />
          </div>
          <div className="block-2">
            <img className="border" src={this.props.Photo_2} alt="Photo 2" />
            <img className="border" src={this.props.Photo_3} alt="Photo 3" />
          </div>
          <div className="block-3">
            <img className="border" src={this.props.Photo_4} alt="Photo 4" />
            <img className="border" src={this.props.Photo_5} alt="Photo 5" />
          </div>
          <div className="block-4">
            <img className="border" src={this.props.Photo_6} alt="Photo 6" />
          </div>
        </div>
      </div>
    );
  }
}
export default LandingGallery;

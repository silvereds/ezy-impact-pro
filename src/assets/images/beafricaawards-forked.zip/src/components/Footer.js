import "./FooterStyles.css";
import {
  FaFacebookSquare,
  FaYoutubeSquare,
  FaTwitterSquare,
  FaInstagramSquare
} from "react-icons/fa";
import Logo from "../assets/logo.png";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <div className="footer">
      <div className="footer-container">
        <div className="bloc-newsletter">
          <div className="bloc-newsletter-top">
            <p>Newsletter & Social Media</p>
          </div>
          <div className="bloc-newsletter-bottom">
            <div className="bloc-newsletter-bottom-form">
              <input
                type="email"
                placeholder="Your email address…"
                id="email"
                name="email"
                className="border roboto-light"
              />
              <div className="btn" id="subscribe">
                Subscribe
              </div>
            </div>
            <div className="bloc-newsletter-bottom-social-media">
              <ul className="bloc-newsletter-bottom-social-media-list">
                <li>
                  <div className="social-media-icon">
                    <a href="ht">
                      <FaFacebookSquare
                        size={20}
                        style={{ color: "#f3cc3cff" }}
                      />
                    </a>
                  </div>
                </li>
                <li>
                  <div className="social-media-icon">
                    <a href="ht">
                      <FaYoutubeSquare
                        size={20}
                        style={{ color: "#f3cc3cff" }}
                      />
                    </a>
                  </div>
                </li>
                <li>
                  <div className="social-media-icon">
                    <a href="ht">
                      <FaTwitterSquare
                        size={20}
                        style={{ color: "#f3cc3cff" }}
                      />
                    </a>
                  </div>
                </li>
                <li>
                  <div className="social-media-icon">
                    <a href="ht">
                      <FaInstagramSquare
                        size={20}
                        style={{ color: "#f3cc3cff" }}
                      />
                    </a>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="bloc-logos">
          <a href="h">
            <img src={Logo} className="logo" alt="logo" />
          </a>
          <a href="h">
            <img src={Logo} className="logo" alt="logo" />
          </a>
          <a href="h">
            <img src={Logo} className="logo" alt="logo" />
          </a>
          <a href="h">
            <img src={Logo} className="logo" alt="logo" />
          </a>
          <a href="h">
            <img src={Logo} className="logo" alt="logo" />
          </a>
          <a href="h">
            <img src={Logo} className="logo" alt="logo" />
          </a>
        </div>
        <div className="bloc-infos">
          <div className="bloc-infos-first">
            <p class="infos-title">BE AFRICA AWARDS</p>
            <p id="infos-first-text">
              An original concept and an annual meeting during which the African
              and International Communities fellow and celebrate the
              achievements of the community through a unique and prestigious
              event.
            </p>
          </div>
          <div className="bloc-infos-second">
            <p class="infos-title">About Us</p>
            <ul>
              <li>
                <Link to="/voting">Votes</Link>
              </li>
              <li>
                <Link to="/about">Awards</Link>
              </li>
              <li>
                <Link to="/">Gala Ceremony</Link>
              </li>
              <li>
                <Link to="/sponsorship">Sponsorship Offer</Link>
              </li>
              <li>
                <Link to="/gallery">Gallery Pictures & Videos</Link>
              </li>
            </ul>
          </div>
          <div className="bloc-infos-last">
            <p class="infos-title">Contact & Address</p>
            <p class="simple-infos">Guangzhou, China</p>
            <Link to="/about">Team Leads here</Link>
            <p class="simple-infos plus">Telephone:</p>
            <p class="simple-infos plus">(+86) 188 4017 9404</p>
            <p class="simple-infos plus">(+86) 135 3555 1394</p>
          </div>
        </div>
        <div className="bloc-ligne">
          <div id="ligne"></div>
        </div>
        <div className="bloc-slogan">
          <p id="slogan">We reward your good work and put it on spotlights.</p>
          <p id="build-infos">April 2023 | Guangzhou, China</p>
        </div>
      </div>
    </div>
  );
};
export default Footer;

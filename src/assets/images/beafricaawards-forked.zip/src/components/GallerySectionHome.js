import "./GallerySectionHomeStyles.css";
import { Component } from "react";
import Crown_5 from "../assets/crown_5.jpg";
import Crown_10 from "../assets/crown_10.jpg";
import Crown_1 from "../assets/crown_1.jpg";
import Crown_2 from "../assets/crown_2.jpg";
import Crown_3 from "../assets/crown_3.jpg";
import Crown_4 from "../assets/crown_4.jpg";
import Crown_6 from "../assets/crown_6.jpg";
import Crown_7 from "../assets/crown_7.jpg";
import Crown_8 from "../assets/crown_8.jpg";
import Crown_9 from "../assets/crown_9.jpg";

import GalleryView from "./GalleryView";
class GallerySectionHome extends Component {
  render() {
    return (
      <div className="secondary-background gallery-home">
        <p className="secondary-title-color gallery-title-part-1">
          OUR GALLERY
        </p>
        <p className="primary-text-color gallery-infos-text roboto-light">
          Some pictures to show you a glimpse of what is to come.
        </p>
        <GalleryView
          Big_Pic_1={Crown_5}
          Big_Pic_2={Crown_10}
          Small_Pic_1={Crown_2}
          Small_Pic_2={Crown_3}
          Small_Pic_3={Crown_4}
          Small_Pic_4={Crown_1}
          Small_Pic_5={Crown_9}
          Small_Pic_6={Crown_8}
          Small_Pic_7={Crown_7}
          Small_Pic_8={Crown_6}
        />
        <p className="btn-light-plus gallery-btn">More here</p>
      </div>
    );
  }
}
export default GallerySectionHome;

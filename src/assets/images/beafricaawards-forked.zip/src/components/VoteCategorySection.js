import VoteCategoryCardView from "./VoteCategoryCardView";
import "./VoteCategorySectionStyles.css";
const { Component } = require("react");

const background_1 = "category-background-1";
const background_2 = "category-background-2";
const icon_1 = "icon-category-1";
const icon_2 = "icon-category-2";
const text_1 = "category-name-1";
const text_2 = "category-name-2";

class VoteCategorySection extends Component {
  render() {
    return (
      <div className="secondary-background categories">
        <p className="vote-category-title secondary-title-color">
          BEST OF THE YEAR
        </p>
        <p className="vote-category-infos primary-text-color roboto-light">
          Click on a category to vote your favorite.
        </p>
        <div className="vote-category">
          <VoteCategoryCardView
            Background={background_1}
            Section=""
            Icon={icon_1}
            Text={text_1}
            Name="AFTER PARTY CLUB"
          />
          <VoteCategoryCardView
            Background={background_2}
            Section=""
            Icon={icon_2}
            Text={text_2}
            Name="AIR CARGO"
          />
          <VoteCategoryCardView
            Background={background_1}
            Section=""
            Icon={icon_1}
            Text={text_1}
            Name="SEA CARGO"
          />
          <VoteCategoryCardView
            Background={background_2}
            Section=""
            Icon={icon_2}
            Text={text_2}
            Name="ARTIST PRODUCER"
          />
          <VoteCategoryCardView
            Background={background_2}
            Section=""
            Icon={icon_2}
            Text={text_2}
            Name="BALLER"
          />
          <VoteCategoryCardView
            Background={background_1}
            Section=""
            Icon={icon_1}
            Text={text_1}
            Name="BUSINESS WOMAN"
          />
          <VoteCategoryCardView
            Background={background_2}
            Section=""
            Icon={icon_2}
            Text={text_2}
            Name="CLUB PROMOTER"
          />
          <VoteCategoryCardView
            Background={background_1}
            Section=""
            Icon={icon_1}
            Text={text_1}
            Name="COMPANY"
          />
          <VoteCategoryCardView
            Background={background_1}
            Section=""
            Icon={icon_1}
            Text={text_1}
            Name="DANCER"
          />
          <VoteCategoryCardView
            Background={background_2}
            Section=""
            Icon={icon_2}
            Text={text_2}
            Name="DJ"
          />
          <VoteCategoryCardView
            Background={background_1}
            Section=""
            Icon={icon_1}
            Text={text_1}
            Name="FEMALE ARTIST"
          />

          <VoteCategoryCardView
            Background={background_2}
            Section=""
            Icon={icon_2}
            Text={text_2}
            Name="MALE ARTIST"
          />
          <VoteCategoryCardView
            Background={background_2}
            Section=""
            Icon={icon_2}
            Text={text_2}
            Name="FOOTBALL PLAYER"
          />
          <VoteCategoryCardView
            Background={background_1}
            Section=""
            Icon={icon_1}
            Text={text_1}
            Name="FOOTBALL TEAM"
          />
          <VoteCategoryCardView
            Background={background_2}
            Section=""
            Icon={icon_2}
            Text={text_2}
            Name="MC"
          />
          <VoteCategoryCardView
            Background={background_1}
            Section=""
            Icon={icon_1}
            Text={text_1}
            Name="MISS GUANGZHOU"
          />
          <VoteCategoryCardView
            Background={background_1}
            Section=""
            Icon={icon_1}
            Text={text_1}
            Name="MODEL"
          />

          <VoteCategoryCardView
            Background={background_2}
            Section=""
            Icon={icon_2}
            Text={text_2}
            Name="NIGHTCLUB"
          />
          <VoteCategoryCardView
            Background={background_1}
            Section=""
            Icon={icon_1}
            Text={text_1}
            Name="PHOTOGRAPHER"
          />
          <VoteCategoryCardView
            Background={background_2}
            Section=""
            Icon={icon_2}
            Text={text_2}
            Name="RESTAURANT"
          />
          <VoteCategoryCardView
            Background={background_2}
            Section=""
            Icon={icon_2}
            Text={text_2}
            Name="SOCIAL MEDIA INFLUENCER"
          />
        </div>
      </div>
    );
  }
}
export default VoteCategorySection;

import "./SponsorshipRequestStyles.css";
import Signature from "../assets/signature.png";
import Request from "../assets/request_sponsorship.png";

const SponsorshipRequest = () => {
  return (
    <div className="sponsorship-request">
      <div className="sponsorship-request-one">
        <div className="sponsorship-request-one-letter secondary-background">
          <p className="sponsorship-request-one-letter-title secondary-title-color">
            REQUEST
            <br />
            FOR SPONSORSHIP
          </p>
          <p className="sponsorship-request-one-letter-content primary-text-color roboto-light">
            Esteemed Madam/Sir,
            <br />
            <br />
            Our event aims to bring together enthusiasts of culture and
            entrepreneurship and generally hard-working actors to make our
            continent proud in China in several sectors of activity.
            <br /> <br />
            Naturally, this requires some means. Thus, we are calling for
            sponsorship. We invite local businesses to join our effort.
            Unquestionably, there are numerous advantages for sponsors. Surely,
            there will be a before and after such collaboration. We are totally
            open to providing more detail about it. Therefore, do not hesitate
            to reach us.
            <br />
            <br />
            Hopefully, you will be sensitive to this request and make the bold
            step to partner with us.
            <br />
            <br />
            Thank You,
            <br />
            <br />
            Yours sincerely,
          </p>
          <img src={Signature} alt="Be-Africa-Awards-Signature" />
        </div>
        <img
          className="sponsorship-request-one-image"
          src={Request}
          alt="Be-Africa-Awards-Signature"
        />
      </div>
      <div className="sponsorship-request-third primary-background">
        <p className="primary-text-color roboto-light">
          Do you want to know more about us? Please, read our motives and
          intentions here…
        </p>
        <p className="btn request-about">About us</p>
      </div>
    </div>
  );
};
export default SponsorshipRequest;

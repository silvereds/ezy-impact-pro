import { Component } from "react";
import "./SponsorshipBenefitsSectionStyles.css";
import SponsorshipBenefitCardView from "./SponsorshipBenefitCardView";
import Star from "../assets/star.png";
import Commercial from "../assets/commercial.png";
import Media from "../assets/media.png";
import Investors from "../assets/investors.png";

class SponsorshipBenefitsSection extends Component {
  render() {
    return (
      <div className="primary-background sponsor-benefits">
        <SponsorshipBenefitCardView
          Icon={Star}
          Title="Notoriety & Branding"
          Infos="Strengthen your notoriety and the branding of your business as well as yours, thanks to the exclusivity and prestige of the Gala. This will surely benefit you as a local actor."
        />
        <SponsorshipBenefitCardView
          Icon={Commercial}
          Title="Commercial Activity & Merchandising"
          Infos="Optimize your commercial activity during the Gala by meeting your future customers (B to B or B to C). Develop your merchandising as well by offering products to the Gala guests."
        />
        <SponsorshipBenefitCardView
          Icon={Media}
          Title="Media Coverage & Marketing"
          Infos="Benefit from our media coverage via social media (more than 35000 potential clients around the world through Facebook, Instagram, Youtube, WeChat, and Whatsapp). Develop a strategy by creating discounts and flyers for example."
        />
        <SponsorshipBenefitCardView
          Icon={Investors}
          Title="Potential Investors & Collaborators"
          Infos="Connect with your next collaborators or future investors from various personalities invited to the Gala (Presidents of Communities, Consuls of several countries, Business leaders, Economic operators, Traders, Students, and the general public)."
        />
      </div>
    );
  }
}
export default SponsorshipBenefitsSection;

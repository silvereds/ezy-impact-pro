import "./LandingAboutStyles.css";
import Gold_Laurel from "../assets/gold_laurel.png";

const LandingAbout = () => {
  return (
    <div className="landing-about primary-background">
      <div className="landing-about-left">
        <p className="fourth-text-color about-what">What is it?</p>
        <p className="landing-about-title primary-title-color">
          BE AFRICA AWARDS
        </p>
        <p className="landing-about-infos secondary-text-color roboto-light">
          An original concept and an annual meeting during which the African and
          International Communities fellow and celebrate the achievements of the
          community through a unique and prestigious event. Many opportunities
          for business growth pop up when talented actors come to meet with
          sponsors and potential investors.
        </p>
        <p className="btn">Vote now</p>
      </div>
      <div className="landing-about-right">
        <img src={Gold_Laurel} alt="Gold-laurel" />
        <div className="landing-about-block-back primary-block border"></div>
      </div>
    </div>
  );
};
export default LandingAbout;

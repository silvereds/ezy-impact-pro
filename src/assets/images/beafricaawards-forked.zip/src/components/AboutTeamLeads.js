import AboutTeamLeadCardView from "./AboutTeamLeadCardView";
import "./AboutTeamLeadsStyles.css";
import Team from "../assets/sponsor_.jpg";
import { Slide } from "react-slideshow-image";
import "react-slideshow-image/dist/styles.css";

const AboutTeamLeads = () => {
  return (
    <div className="primary-background about-team-leads">
      <div className="small-device-team-leads-section">
        <p className="secondary-title-color small-device-team-title">
          THE TEAM LEADS
        </p>
        <p className="primary-text-color roboto-light small-device-team-infos">
          We are a efficient team of passionate and qualified people dedicated.
          Here are our 3 Team Leaders.
        </p>
      </div>
      <Slide>
        <div className="each-slide-team-leads">
          <div className="big-device-team-leads-section">
            <p className="fourth-text-color">Want to meet us?</p>
            <p className="secondary-title-color team-leads-title">
              THE TEAM LEADS
            </p>
            <p className="primary-text-color roboto-light team-leads-infos">
              We are a efficient team of passionate and qualified people
              dedicated to uplifting our communities. The team is big. However,
              here are our 3 Team Leaders. Do not hesitate to follow them on
              social media to get to know them more.
              <br />
              <br />
              Moreover, there is an upcoming event. More about it here.
            </p>
            <p className="btn">Our new event here</p>
          </div>
          <AboutTeamLeadCardView
            Picture_Team_Lead={Team}
            Name_Team_Lead="Name of the Lead 1"
            Small_Description_Team_Lead="Small description of the lead 3.  (3 shorts lines). Small description of the lead 3."
            F_link="ht"
            Y_link="ht"
            T_link="ht"
            I_link="ht"
          />
        </div>
        <div className="each-slide-team-leads">
          <div className="big-device-team-leads-section">
            <p className="fourth-text-color">Want to meet us?</p>
            <p className="secondary-title-color team-leads-title">
              THE TEAM LEADS
            </p>
            <p className="primary-text-color roboto-light team-leads-infos">
              We are a efficient team of passionate and qualified people
              dedicated to uplifting our communities. The team is big. However,
              here are our 3 Team Leaders. Do not hesitate to follow them on
              social media to get to know them more.
              <br />
              <br />
              Moreover, there is an upcoming event. More about it here.
            </p>
            <p className="btn">Our new event here</p>
          </div>
          <AboutTeamLeadCardView
            Picture_Team_Lead={Team}
            Name_Team_Lead="Name of the Lead 1"
            Small_Description_Team_Lead="Small description of the lead 3.  (3 shorts lines). Small description of the lead 3."
            F_link="ht"
            Y_link="ht"
            T_link="ht"
            I_link="ht"
          />
        </div>
        <div className="each-slide-team-leads">
          <div className="big-device-team-leads-section">
            <p className="fourth-text-color">Want to meet us?</p>
            <p className="secondary-title-color team-leads-title">
              THE TEAM LEADS
            </p>
            <p className="primary-text-color roboto-light team-leads-infos">
              We are a efficient team of passionate and qualified people
              dedicated to uplifting our communities. The team is big. However,
              here are our 3 Team Leaders. Do not hesitate to follow them on
              social media to get to know them more.
              <br />
              <br />
              Moreover, there is an upcoming event. More about it here.
            </p>
            <p className="btn">Our new event here</p>
          </div>
          <AboutTeamLeadCardView
            Picture_Team_Lead={Team}
            Name_Team_Lead="Name of the Lead 1"
            Small_Description_Team_Lead="Small description of the lead 3.  (3 shorts lines). Small description of the lead 3."
            F_link="ht"
            Y_link="ht"
            T_link="ht"
            I_link="ht"
          />
        </div>
      </Slide>
    </div>
  );
};
export default AboutTeamLeads;

import { Component } from "react";
import "./SponsorshipBenefitCardViewStyles.css";

class SponsorshipBenefitCardView extends Component {
  render() {
    return (
      <div className="benefit-card-view">
        <div className="benefit-card-view-icon border">
          <img src={this.props.Icon} alt="Star" />
        </div>
        <p className="benefit-card-view-title">{this.props.Title}</p>
        <p className="benefit-card-view-infos">{this.props.Infos}</p>
      </div>
    );
  }
}
export default SponsorshipBenefitCardView;

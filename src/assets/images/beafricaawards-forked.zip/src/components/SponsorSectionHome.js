import SponsorCardHome from "./SponsorCardHome";
import "./SponsorSectionHomeStyles.css";
import Logo from "../assets/logo.png";
import Sponsor from "../assets/sponsor_.jpg";
import Sponsor1 from "../assets/sponsor_2.jpg";
import Sponsor2 from "../assets/sponsor_7.jpg";
import { Slide } from "react-slideshow-image";
import "react-slideshow-image/dist/styles.css";

const SponsorSectionHome = () => {
  return (
    <div className="sponsor-container secondary-background">
      <div className="secondary-background sponsor-home">
        <div className="sponsor-small-device">
          <p className="secondary-title-color sponsor-title-part-1">
            MEET OUR SPONSORS
          </p>
          <p className="primary-text-color sponsor-infos-text roboto-light">
            Meet our sponsors for the upcoming event. The Gala is planned for
            this 28th of April.
          </p>
        </div>
        <Slide>
          <div className="each-slide">
            <div className="slide-left sponsor-big-device">
              <p className="secondary-title-color sponsor-title-part-1">
                MEET OUR
              </p>
              <p className="secondary-title-color sponsor-title-part-2">
                SPONSORS
              </p>
              <p className="primary-text-color sponsor-infos-text roboto-light">
                Meet our sponsors for the upcoming event. The Gala is planned
                for this 28th of April. There is still a possibility to become a
                sponsor and win incredible benefits.
              </p>
              <p className="btn">Become a sponsor</p>
            </div>
            <SponsorCardHome
              Logo={Logo}
              Status="A - Official"
              Name="NAME OF THE SPONSOR"
              F_link="ht"
              Y_link="ht"
              T_link="ht"
              I_link="ht"
              Description="Here is a space for the small description of the sponsor. It can have many lignes. No problem. Here is a space for the small description of the sponsor."
              Pic_1={Sponsor}
              Pic_2={Sponsor}
              Pic_3={Sponsor}
              Website="ht"
            />
          </div>
          <div className="each-slide">
            <div className="slide-left sponsor-big-device">
              <p className="secondary-title-color sponsor-title-part-1">
                MEET OUR
              </p>
              <p className="secondary-title-color sponsor-title-part-2">
                SPONSORS
              </p>
              <p className="primary-text-color sponsor-infos-text roboto-light">
                Meet our sponsors for the upcoming event. The Gala is planned
                for this 28th of April. There is still a possibility to become a
                sponsor and win incredible benefits.
              </p>
              <p className="btn">Become a sponsor</p>
            </div>
            <SponsorCardHome
              Logo={Logo}
              Status="A - Official"
              Name="NAME OF THE SPONSOR"
              F_link="ht"
              Y_link="ht"
              T_link="ht"
              I_link="ht"
              Description="Here is a space for the small description of the sponsor. It can have many lignes. No problem. Here is a space for the small description of the sponsor."
              Pic_1={Sponsor2}
              Pic_2={Sponsor2}
              Pic_3={Sponsor2}
              Website="ht"
            />
          </div>
          <div className="each-slide">
            <div className="slide-left sponsor-big-device">
              <p className="secondary-title-color sponsor-title-part-1">
                MEET OUR
              </p>
              <p className="secondary-title-color sponsor-title-part-2">
                SPONSORS
              </p>
              <p className="primary-text-color sponsor-infos-text roboto-light">
                Meet our sponsors for the upcoming event. The Gala is planned
                for this 28th of April. There is still a possibility to become a
                sponsor and win incredible benefits.
              </p>
              <p className="btn">Become a sponsor</p>
            </div>
            <SponsorCardHome
              Logo={Logo}
              Status="A - Official"
              Name="NAME OF THE SPONSOR"
              F_link="ht"
              Y_link="ht"
              T_link="ht"
              I_link="ht"
              Description="Here is a space for the small description of the sponsor. It can have many lignes. No problem. Here is a space for the small description of the sponsor."
              Pic_1={Sponsor1}
              Pic_2={Sponsor}
              Pic_3={Sponsor2}
              Website="ht"
            />
          </div>
        </Slide>
      </div>
      <div className="primary-background sponsor-offer">
        <p className="primary-text-color roboto-light sponsorship-infos">
          Do you want to become a sponsor for the upcoming event? Please, have a
          look at the multiple benefits of partnering with us.
        </p>
        <p className="btn" id="btn-sponsorship">
          Sponsorship benefits
        </p>
      </div>
    </div>
  );
};
export default SponsorSectionHome;

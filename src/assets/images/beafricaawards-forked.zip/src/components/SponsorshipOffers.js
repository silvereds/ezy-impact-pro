import SponsorshipOfferCardView from "./SponsorshipOfferCardView";
import "./SponsorshipOffersStyles.css";
import { Slide } from "react-slideshow-image";
import "react-slideshow-image/dist/styles.css";

const SponsorshipOffers = () => {
  const infos_1 =
    "55% display in banners (printed by you) installed inside the room. 1 passage of 10 minutes on the stage to present your services. 1 passage every 20 minutes on the giant screen. Provision of 5 invitations to the gala. And so much more...";
  const infos_2 =
    "35% display in banners (printed by you) installed inside the room. 1 passage every 40 minutes on the giant screen. Provision of 3 invitations to the gala. And more...";
  const infos_3 =
    "15% display in banners (printed by you) installed inside the room. 1 passage every 1 hour on the giant screen. Provision of 3 invitations to the gala. And more...";

  return (
    <div className="secondary-background sponsorship-offers">
      <div className="become-sponsors-infos">
        <p className="become-sponsors-infos-title secondary-title-color">
          BECOME A SPONSOR
        </p>
        <p className="become-sponsors-infos-text primary-text-color roboto-light">
          Join our special boat to uplift one another and increase the impact in
          our communities. Of course, there are countless advantages for your
          business!
        </p>
      </div>
      <Slide>
        <div className="each-slide-sponsorship">
          <p className="infos-sponsorship-large-screen roboto-light primary-text-color">
            Pick one option that suits you the most among the three available
            (A, B, or C).
          </p>
          <SponsorshipOfferCardView
            Offer_Type="A."
            Class="OFFICIAL"
            Infos={infos_1}
            Amount="10000 - 50000"
          />
        </div>
        <div className="each-slide-sponsorship">
          <p className="infos-sponsorship-large-screen roboto-light primary-text-color">
            Pick one option that suits you the most among the three available
            (A, B, or C).
          </p>
          <SponsorshipOfferCardView
            Offer_Type="B."
            Class="Partner"
            Infos={infos_2}
            Amount="7500 - 25000"
          />
        </div>
        <div className="each-slide-sponsorship">
          <p className="infos-sponsorship-large-screen roboto-light primary-text-color">
            Pick one option that suits you the most among the three available
            (A, B, or C).
          </p>
          <SponsorshipOfferCardView
            Offer_Type="C."
            Class="Partner"
            Infos={infos_3}
            Amount="5000 - 15000"
          />
        </div>
      </Slide>
    </div>
  );
};
export default SponsorshipOffers;

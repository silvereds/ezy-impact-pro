import { Component } from "react";
import VoteCardView from "../components/VoteCardView";
import Nominee from "../assets/home_vote_2.jpeg";
import { Slide } from "react-slideshow-image";
import "react-slideshow-image/dist/styles.css";
import "./VotePhoneStyles.css";

class VotePhotographerSmall extends Component {
  render() {
    return (
      <div className="vote-phone">
        <p className="secondary-title-color vote-title">
          BEST PHOTOGRAPHER OF THE YEAR
        </p>
        <p className="primary-text-color vote-guidance ">
          Vote for your favorite as much as possible.
        </p>
        <Slide>
          <div className="each-slide-vote-phone">
            <VoteCardView
              Background="secondary_bg"
              Nominee={Nominee}
              Count="3000"
              Name="Name of Company"
              Description="Small description of the company. (2 shorts lines).Small description of the company. (2 shorts lines)"
            />
          </div>
          <div className="each-slide-vote-phone">
            <VoteCardView
              Background="secondary_bg"
              Nominee={Nominee}
              Count="3000"
              Name="Name of Company"
              Description="Small description of the company. (2 shorts lines).Small description of the company. (2 shorts lines)"
            />
          </div>
          <div className="each-slide-vote-phone">
            <VoteCardView
              Background="secondary_bg"
              Nominee={Nominee}
              Count="3000"
              Name="Name of Company"
              Description="Small description of the company. (2 shorts lines).Small description of the company. (2 shorts lines)"
            />
          </div>
          <div className="each-slide-vote-phone">
            <VoteCardView
              Background="secondary_bg"
              Nominee={Nominee}
              Count="3000"
              Name="Name of Company"
              Description="Small description of the company. (2 shorts lines).Small description of the company. (2 shorts lines)"
            />
          </div>
          <div className="each-slide-vote-phone">
            <VoteCardView
              Background="secondary_bg"
              Nominee={Nominee}
              Count="3000"
              Name="Name of Company"
              Description="Small description of the company. (2 shorts lines).Small description of the company. (2 shorts lines)"
            />
          </div>
          <div className="each-slide-vote-phone">
            <VoteCardView
              Background="secondary_bg"
              Nominee={Nominee}
              Count="3000"
              Name="Name of Company"
              Description="Small description of the company. (2 shorts lines).Small description of the company. (2 shorts lines)"
            />
          </div>
          <div className="each-slide-vote-phone">
            <VoteCardView
              Background="secondary_bg"
              Nominee={Nominee}
              Count="3000"
              Name="Name of Company"
              Description="Small description of the company. (2 shorts lines).Small description of the company. (2 shorts lines)"
            />
          </div>
        </Slide>
      </div>
    );
  }
}
export default VotePhotographerSmall;

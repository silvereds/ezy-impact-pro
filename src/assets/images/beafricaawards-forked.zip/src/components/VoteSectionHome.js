import "./VoteSectionHomeStyles.css";
import Image1 from "../assets/home_vote_1.jpg";

const VoteSectionHome = () => {
  return (
    <div className="vote-home primary-background">
      <div className="vote-left">
        <p className="secondary-title-color vote-title-part-1">BE AFRICA</p>
        <p className="secondary-title-color vote-title-part-2">AWARDS VOTE</p>
        <p className="primary-text-color vote-infos-text roboto-light">
          There are in sum 14 categories. The voting process goes from… to...
          The grand ceremony will be held on the 28th of April this year. Make
          sure you vote for your favorite.
        </p>
        <p className="btn">Vote now</p>
      </div>
      <div className="vote-right">
        <img src={Image1} className="vote-img border" alt="vote-img-1" />
        <div className="infos-plus border">
          <p className="roboto-light third-text-color">
            To vote, make sure you have a <em>Google</em> or <em>Facebook</em>{" "}
            account.
          </p>
        </div>
        <div className="infos-plus border">
          <p className="roboto-light ">
            You can <em>buy</em> votes for your <em>favorites</em>.
          </p>
        </div>
        <img
          src={Image1}
          className="vote-img border"
          id="visible"
          alt="vote-img-2"
        />
      </div>
    </div>
  );
};
export default VoteSectionHome;

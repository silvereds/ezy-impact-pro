import "./LandingSponsorshipStyles.css";
import Sponsor from "../assets/gold_sponsor.png";

const LandingSponsorship = () => {
  return (
    <div class="landing-sponsorship">
      <div className="landing-sponsorship-left">
        <p class="landing-sponsorship-title-part-1">BE AFRICA AWARDS</p>
        <p class="landing-sponsorship-title-part-2">SPONSORSHIP</p>
        <p className="landing-sponsorship-infos-text roboto-light">
          It is an efficient communication strategy for companies. The challenge
          is to make your company prominent before and during the Gala to
          enhance your brand's name, extend your market, attract potential
          investors, and give you possibilities to refine your products or
          services.
        </p>
        <p className="btn">Details here</p>
      </div>
      <div className="landing-sponsorship-image">
        <img className="landing-sponsorship-right" src={Sponsor} alt="Awards" />
      </div>
    </div>
  );
};
export default LandingSponsorship;

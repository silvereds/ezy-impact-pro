import "./CommunitiesSectionHomeStyles.css";
import Africa from "../assets/africa_community.png";

const CommunitiesSectionHome = () => {
  return (
    <div className="primary-background communities-home">
      <div>
        <p className="secondary-title-color communities-title-part-1">
          BE AFRICA <br />
          AWARDS <br />
          COMMUNITIES
        </p>
        <p className="primary-text-color roboto-light communities-infos-text">
          The African community and the international community are all part of
          the movement. Africa, America, Asia, Europe, and Oceania are all
          welcome.
        </p>
        <p className="btn">More about the awards</p>
      </div>
      <img src={Africa} alt="Africa-community" />
    </div>
  );
};
export default CommunitiesSectionHome;

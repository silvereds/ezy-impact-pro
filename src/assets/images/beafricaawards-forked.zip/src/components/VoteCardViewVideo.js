import YoutubeEmbed from "./YoutubeEmbed";
import "./VoteCardViewVideoStyles.css";
const { Component } = require("react");

class VoteCardViewVideo extends Component {
  render() {
    return (
      <div className="vote-card-view border" id={this.props.Background}>
        <div className="vote-card-video">
          <YoutubeEmbed embedId={this.props.Nominee} />
        </div>
        <div className="vote-card-padding">
          <p className="vote-card-count border">{this.props.Count}</p>
          <p className="vote-card-title">{this.props.Name}</p>
          <p className="vote-card-infos">{this.props.Description}</p>
          <div className="vote-card-buttons">
            <p className="btn">Vote</p>
            <p className="btn-light">Buy</p>
          </div>
        </div>
      </div>
    );
  }
}
export default VoteCardViewVideo;

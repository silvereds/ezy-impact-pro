import "./SponsorCardHomeStyles.css";
import { Component } from "react";
import { HashLink } from "react-router-hash-link";
import {
  TbCategory,
  TbBrandFacebook,
  TbBrandYoutube,
  TbBrandTwitter,
  TbBrandInstagram
} from "react-icons/tb";

class SponsorCardHome extends Component {
  render() {
    return (
      <div className="sponsor-card border">
        <div className="sponsor-left">
          <a href={this.props.Website} className="sponsor-top-left">
            <img
              src={this.props.Logo}
              className="sponsor-logo border"
              alt="sponsor-logo"
            />
          </a>
          <div className="sponsor-left-bottom">
            <HashLink smooth to="/#section_1" className="visible">
              <TbCategory size={22} style={{ color: "#f3cc3cff" }} />
            </HashLink>
            <p>{this.props.Status}</p>
          </div>
        </div>
        <div className="sponsor-right">
          <div className="sponsor-right-first">
            <p className="name-sponsor">{this.props.Name}</p>
            <ul className="sponsor-social-media">
              <li>
                <a href={this.props.F_link}>
                  <TbBrandFacebook size={22} style={{ color: "#f3cc3cff" }} />
                </a>
              </li>
              <li>
                <a href={this.props.Y_link}>
                  <TbBrandYoutube size={22} style={{ color: "#f3cc3cff" }} />
                </a>
              </li>
              <li>
                <a href={this.props.T_link}>
                  <TbBrandTwitter size={22} style={{ color: "#f3cc3cff" }} />
                </a>
              </li>
              <li>
                <a href={this.props.I_link}>
                  <TbBrandInstagram size={22} style={{ color: "#f3cc3cff" }} />
                </a>
              </li>
            </ul>
          </div>
          <p className="sponsor-right-second roboto-light">
            {this.props.Description}
          </p>
          <ul className="sponsor-right-third">
            <li>
              <img
                src={this.props.Pic_1}
                alt="sponsor-img"
                className="border"
              />
            </li>
            <li>
              <img
                src={this.props.Pic_2}
                alt="sponsor-img"
                className="visible border"
              />
            </li>
            <li>
              <img
                src={this.props.Pic_3}
                alt="sponsor-img"
                className="visible border"
              />
            </li>
          </ul>
          <div className="btn-light-plus special-btn">More here</div>
        </div>
      </div>
    );
  }
}
export default SponsorCardHome;

import "./NavbarStyles.css";
import Logo from "../assets/logo.png";
import { Link } from "react-router-dom";
import { FaBars, FaTimes } from "react-icons/fa";
import { Component } from "react";
import { HashLink } from "react-router-hash-link";

class Navbar extends Component {
  state = { clicked: false };
  handleClick = () => {
    this.setState({ clicked: !this.state.clicked });
  };

  render() {
    return (
      <div className="header">
        <Link to="/">
          <img src={Logo} className="logo" alt="logo" />
        </Link>
        <ul className={this.state.clicked ? "nav-menu active" : "nav-menu"}>
          <li>
            <Link to="/" id={this.props.home}>
              Home
            </Link>
          </li>
          <li>
            <Link to="/voting" id={this.props.voting}>
              Voting
            </Link>
          </li>
          <li>
            <Link to="/gallery" id={this.props.gallery}>
              Gallery
            </Link>
          </li>
          <li>
            <Link to="/sponsorship" id={this.props.sponsorship}>
              Sponsorship
            </Link>
          </li>
          <li>
            <Link to="/about" id={this.props.about}>
              About Us
            </Link>
          </li>
          <li>
            <HashLink
              smooth
              to="/about/#id_contact_us"
              className="hashlink"
              id={this.props.contact}
            >
              Contact Us
            </HashLink>
          </li>
        </ul>
        <div className="hamburger" onClick={this.handleClick}>
          {this.state.clicked ? (
            <FaTimes
              className="icon"
              size={25}
              style={{ color: "#f3cc3cff" }}
            />
          ) : (
            <FaBars className="icon" size={25} style={{ color: "#f3cc3cff" }} />
          )}
        </div>
      </div>
    );
  }
}
export default Navbar;

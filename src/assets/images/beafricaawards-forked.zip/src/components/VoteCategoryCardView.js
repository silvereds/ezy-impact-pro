import "./VoteCategoryCardViewStyles.css";
import { HashLink } from "react-router-hash-link";
import { GiLaurelsTrophy } from "react-icons/gi";
import { Component } from "react";

class VoteCategoryCardView extends Component {
  render() {
    return (
      <div className={this.props.Background}>
        <HashLink
          smooth
          to={`/voting/#${this.props.Section}`}
          className="hashlink"
        >
          <GiLaurelsTrophy size={40} className={this.props.Icon} />
          <p className={this.props.Text}>{this.props.Name}</p>
        </HashLink>
      </div>
    );
  }
}
export default VoteCategoryCardView;

import "./LandingHomeStyles.css";
import YoutubeEmbed from "./YoutubeEmbed";
import { HashLink } from "react-router-hash-link";

const LandingHome = () => {
  return (
    <div class="landing primary-background">
      <div className="left">
        <p class="title-part-1">BE AFRICA </p>
        <p class="title-part-2">AWARDS</p>
        <p className="infos-text roboto-light">
          An original concept aiming to acknowledge, appreciate, expose, and
          reward the expertise of the African Community in Guangzhou, China.
          Furthermore, it is an opportunity for business exposure through
          sponsorship. Learn more about this year's edition below.
        </p>
        <HashLink smooth to="/voting/#voting-cat" className="hashlink">
          <p className="btn">Vote now</p>
        </HashLink>
      </div>
      <div className="right">
        <YoutubeEmbed embedId="afTXmBPOMng" />
      </div>
    </div>
  );
};
export default LandingHome;

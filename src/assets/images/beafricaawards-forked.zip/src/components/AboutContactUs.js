import Contact from "../assets/contact.jpeg";
import "./AboutContactUsStyles.css";
import { Component, React } from "react";

class AboutContactUs extends Component {
  render() {
    return (
      <div className="about-contact-us secondary-background">
        <div className="about-contact-left">
          <img className="border" src={Contact} alt="Contact" />
          <div className="contact-block secondary-block border"></div>
        </div>
        <div className="about-contact-right">
          <p className="fourth-text-color">Any question?</p>
          <p className="secondary-title-color contact-title">CONTACT US</p>
          <p className="secondary-text-color roboto-light contact-infos">
            Please, contact us for any of your concerns. We will be glad to hear
            from you and eventually collaborate with you to enrich our community
            even more.
          </p>
          <input
            type="email"
            placeholder="Your email address..."
            id="email_contact"
            name="email_contact"
            className="border textfields roboto-thin"
          />
          <input
            type="text"
            placeholder="Your object..."
            id="object"
            name="object"
            className="border textfields roboto-thin"
          />
          <textarea
            placeholder="Your message…"
            rows="5"
            cols="30"
            className="textfields border roboto-thin"
            id="message"
          />
          <p className="btn" id="btn-send">
            Send
          </p>
        </div>
      </div>
    );
  }
}
export default AboutContactUs;

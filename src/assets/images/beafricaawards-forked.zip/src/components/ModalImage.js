import Photo from "../assets/sponsor_6.jpg";
import "./ModalImageStyles.css";
import { Component } from "react";
import { ModalJS } from "../scripts/modal.js";
import { Helmet } from "react-helmet";

class ModalImage extends Component {
  render() {
    return (
      <div>
        <img id="myImg" src={Photo} alt="Snow" />
        <div id="myModal" class="modal">
          <span class="close">&times;</span>
          <img class="modal-content" id="img01" />
          <div id="caption"></div>
        </div>
        <Helmet>
          <script src={ModalJS} type="text/javascript" />
        </Helmet>
      </div>
    );
  }
}
export default ModalImage;

var modal, img, modalImg, captionText, span;

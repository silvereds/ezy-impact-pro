import Footer from "../components/Footer";
import LandingVoting from "../components/LandingVoting";
import Navbar from "../components/Navbar";
import VoteAfterParty from "../components/VoteAfterParty";
import VoteAirCargoSmall from "../components/VoteAirCargoSmall";
import VoteBallerBig from "../components/VoteBallerBig";
import VoteBallerSmall from "../components/VoteBallerSmall";
import VoteBusinessWomanBig from "../components/VoteBusinessWomanBig";
import VoteBusinessWomanSmall from "../components/VoteBusinessWomanSmall";
import VoteCargoAirBig from "../components/VoteCargoAirBig";
import VoteCategorySection from "../components/VoteCategorySection";
import VoteClubPromoterBig from "../components/VoteClubPromoterBig";
import VoteClubPromoterSmall from "../components/VoteClubPromoterSmall";
import VoteCompanyBig from "../components/VoteCompanyBig";
import VoteCompanySmall from "../components/VoteCompanySmall";
import VoteDancerBig from "../components/VoteDancerBig";
import VoteDancerSmall from "../components/VoteDancerSmall";
import VoteDJBig from "../components/VoteDJBig";
import VoteDJSmall from "../components/VoteDJSmall";
import VoteFemaleArtistBig from "../components/VoteFemaleArtistBig";
import VoteFemaleArtistSmall from "../components/VoteFemaleArtistSmall";
import VoteFootballPlayerBig from "../components/VoteFootballPlayerBig";
import VoteFootballPlayerSmall from "../components/VoteFootballPlayerSmall";
import VoteMaleArtistBig from "../components/VoteMaleArtistBig";
import VoteMaleArtistSmall from "../components/VoteMaleArtistSmall";
import VoteMCBig from "../components/VoteMCBig";
import VoteMCSmall from "../components/VoteMCSmall";
import VoteMissGuangzhouBig from "../components/VoteMissGuangzhouBig";
import VoteMissGuangzhouSmall from "../components/VoteMissGuangzhouSmall";
import VoteModelBig from "../components/VoteModelBig";
import VoteModelSmall from "../components/VoteModelSmall";
import VoteNightclubBig from "../components/VoteNightclubBig";
import VoteNightclubSmall from "../components/VoteNightclubSmall";
import VotePhotographerBig from "../components/VotePhotographerBig";
import VotePhotographerSmall from "../components/VotePhotographerSmall";
import VoteRestaurantBig from "../components/VoteRestaurantBig";
import VoteRestaurantSmall from "../components/VoteRestaurantSmall";
import VoteSeaCargoBig from "../components/VoteSeaCargoBig";
import VoteSeaCargoSmall from "../components/VoteSeaCargoSmall";
import VoteSection from "../components/VoteSection";
import VoteSocialMediaInfluencerBig from "../components/VoteSocialMediaInfluencerBig";
import VoteSocialMediaInfluencerSmall from "../components/VoteSocialMediaInfluencerSmall";
import "../components/VotingStyles.css";

const Voting = () => {
  return (
    <div>
      <Navbar
        home="null"
        voting="voting"
        gallery="null"
        sponsorship="null"
        about="null"
        contact="null"
      />
      <LandingVoting />
      <div id="voting-cat">
        <VoteCategorySection />
      </div>
      <div id="v-ap">
        <div className="primary-background">
          <div className="version-big-screen">
            <VoteSection />
          </div>
          <div className="version-small-screen">
            <VoteAfterParty />
          </div>
        </div>
      </div>
      <div className="secondary-background">
        <div className="version-big-screen">
          <VoteCargoAirBig />
        </div>
        <div className="version-small-screen">
          <VoteAirCargoSmall />
        </div>
      </div>
      <div className="primary-background">
        <div className="version-big-screen">
          <VoteSeaCargoBig />
        </div>
        <div className="version-small-screen">
          <VoteSeaCargoSmall />
        </div>
      </div>

      <div className="secondary-background">
        <div className="version-big-screen">
          <VoteBallerBig />
        </div>
        <div className="version-small-screen">
          <VoteBallerSmall />
        </div>
      </div>

      <div className="primary-background">
        <div className="version-big-screen">
          <VoteBusinessWomanBig />
        </div>
        <div className="version-small-screen">
          <VoteBusinessWomanSmall />
        </div>
      </div>
      <div className="secondary-background">
        <div className="version-big-screen">
          <VoteClubPromoterBig />
        </div>
        <div className="version-small-screen">
          <VoteClubPromoterSmall />
        </div>
      </div>
      <div className="primary-background">
        <div className="version-big-screen">
          <VoteCompanyBig />
        </div>
        <div className="version-small-screen">
          <VoteCompanySmall />
        </div>
      </div>
      <div className="secondary-background">
        <div className="version-big-screen">
          <VoteDancerBig />
        </div>
        <div className="version-small-screen">
          <VoteDancerSmall />
        </div>
      </div>
      <div className="primary-background">
        <div className="version-big-screen">
          <VoteDJBig />
        </div>
        <div className="version-small-screen">
          <VoteDJSmall />
        </div>
      </div>

      <div className="secondary-background">
        <div className="version-big-screen">
          <VoteFemaleArtistBig />
        </div>
        <div className="version-small-screen">
          <VoteFemaleArtistSmall />
        </div>
      </div>

      <div className="primary-background">
        <div className="version-big-screen">
          <VoteMaleArtistBig />
        </div>
        <div className="version-small-screen">
          <VoteMaleArtistSmall />
        </div>
      </div>

      <div className="secondary-background">
        <div className="version-big-screen">
          <VoteFootballPlayerBig />
        </div>
        <div className="version-small-screen">
          <VoteFootballPlayerSmall />
        </div>
      </div>

      <div className="primary-background">
        <div className="version-big-screen">
          <VoteMCBig />
        </div>
        <div className="version-small-screen">
          <VoteMCSmall />
        </div>
      </div>

      <div className="secondary-background">
        <div className="version-big-screen">
          <VoteMissGuangzhouBig />
        </div>
        <div className="version-small-screen">
          <VoteMissGuangzhouSmall />
        </div>
      </div>

      <div className="primary-background">
        <div className="version-big-screen">
          <VoteModelBig />
        </div>
        <div className="version-small-screen">
          <VoteModelSmall />
        </div>
      </div>

      <div className="secondary-background">
        <div className="version-big-screen">
          <VoteNightclubBig />
        </div>
        <div className="version-small-screen">
          <VoteNightclubSmall />
        </div>
      </div>

      <div className="primary-background">
        <div className="version-big-screen">
          <VotePhotographerBig />
        </div>
        <div className="version-small-screen">
          <VotePhotographerSmall />
        </div>
      </div>

      <div className="secondary-background">
        <div className="version-big-screen">
          <VoteRestaurantBig />
        </div>
        <div className="version-small-screen">
          <VoteRestaurantSmall />
        </div>
      </div>

      <div className="primary-background">
        <div className="version-big-screen">
          <VoteSocialMediaInfluencerBig />
        </div>
        <div className="version-small-screen">
          <VoteSocialMediaInfluencerSmall />
        </div>
      </div>

      <Footer />
    </div>
  );
};
export default Voting;

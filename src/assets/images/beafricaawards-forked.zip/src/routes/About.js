import AboutContactUs from "../components/AboutContactUs";
import AboutSponsorship from "../components/AboutSponsorship";
import AboutTeamLeads from "../components/AboutTeamLeads";
import Footer from "../components/Footer";
import LandingAbout from "../components/LandingAbout";
import Navbar from "../components/Navbar";

const About = () => {
  return (
    <div>
      <Navbar
        home="null"
        voting="null"
        gallery="null"
        sponsorship="null"
        about="about"
        contact="null"
      />
      <LandingAbout />
      <AboutSponsorship />
      <div id="id_contact_us">
        <AboutContactUs />
      </div>
      <AboutTeamLeads />
      <Footer />
    </div>
  );
};
export default About;

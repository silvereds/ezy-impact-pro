import Footer from "../components/Footer";
import LandingGallery from "../components/LandingGallery";
import Navbar from "../components/Navbar";
import Photo from "../assets/sponsor_.jpg";
import GalleryPictures from "../components/GalleryPictures";
import GalleryVideos from "../components/GalleryVideos";

const Gallery = () => {
  return (
    <div>
      <Navbar
        home="null"
        voting="null"
        gallery="gallery"
        sponsorship="null"
        about="null"
        contact="null"
      />
      <LandingGallery
        Photo_1={Photo}
        Photo_2={Photo}
        Photo_3={Photo}
        Photo_4={Photo}
        Photo_5={Photo}
        Photo_6={Photo}
      />
      <GalleryPictures />
     <GalleryVideos/>
      <Footer />
    </div>
  );
};
export default Gallery;

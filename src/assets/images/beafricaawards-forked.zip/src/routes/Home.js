import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import LandingHome from "../components/LandingHome";
import GalaSectionHome from "../components/GalaSectionHome";
import VoteSectionHome from "../components/VoteSectionHome";
import SponsorSectionHome from "../components/SponsorSectionHome";
import GallerySectionHome from "../components/GallerySectionHome";
import CommunitiesSectionHome from "../components/CommunitiesSectionHome";

const Home = () => {
  return (
    <div>
      <Navbar
        home="home"
        voting="null"
        gallery="null"
        sponsorship="null"
        about="null"
        contact="null"
      />
      <div id="section_1">
        <LandingHome />
      </div>

      <GalaSectionHome id="section_2" />
      <VoteSectionHome />
      <SponsorSectionHome />
      <GallerySectionHome />
      <CommunitiesSectionHome />
      <Footer />
    </div>
  );
};
export default Home;

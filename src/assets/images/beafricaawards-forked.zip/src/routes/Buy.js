import Footer from "../components/Footer";
import Navbar from "../components/Navbar";
import VoteBuy from "../components/VoteBuy";

const Contact = () => {
  return (
    <div>
      <Navbar
        home="null"
        voting="voting"
        gallery="null"
        sponsorship="null"
        about="null"
        contact="null"
      />
      <VoteBuy />
      <Footer />
    </div>
  );
};
export default Contact;

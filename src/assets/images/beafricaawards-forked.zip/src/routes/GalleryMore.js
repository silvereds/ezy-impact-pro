import Footer from "../components/Footer";
import Navbar from "../components/Navbar";

const GalleryMore = () => {
  return (
    <div>
      <Navbar
        home="null"
        voting="null"
        gallery="gallery"
        sponsorship="null"
        about="null"
        contact="null"
      />
      <p className="btn-light">Je veux verifier un truc</p>
      <Footer />
    </div>
  );
};
export default GalleryMore;

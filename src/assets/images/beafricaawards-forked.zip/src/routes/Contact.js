import Footer from "../components/Footer";
import Navbar from "../components/Navbar";

const Contact = () => {
  return (
    <div>
      <Navbar
        home="null"
        voting="null"
        gallery="null"
        sponsorship="null"
        about="null"
        contact="contact"
      />
      <p className="btn-light">Je veux verifier un truc</p>
      <Footer />
    </div>
  );
};
export default Contact;

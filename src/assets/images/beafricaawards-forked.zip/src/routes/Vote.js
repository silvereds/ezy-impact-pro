import Footer from "../components/Footer";
import Navbar from "../components/Navbar";
import VoteProcess from "../components/VoteProcess";

const Vote = () => {
  return (
    <div>
      <Navbar
        home="null"
        voting="voting"
        gallery="null"
        sponsorship="null"
        about="null"
        contact="null"
      />
      <VoteProcess />
      <Footer />
    </div>
  );
};
export default Vote;

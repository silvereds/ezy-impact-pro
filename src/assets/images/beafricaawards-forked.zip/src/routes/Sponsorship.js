import Footer from "../components/Footer";
import LandingSponsorship from "../components/LandingSponsorship";
import Navbar from "../components/Navbar";
import ReachNewAudienceSectionSponsorship from "../components/ReachNewAudienceSectionSponsorship";
import SponsorshipBenefitsSection from "../components/SponsorshipBenefitsSection";
import SponsorshipGalaExposure from "../components/SponsorshipGalaExposure";
import SponsorshipOffers from "../components/SponsorshipOffers";
import SponsorshipRequest from "../components/SponsorshipRequest";

const Sponsorship = () => {
  return (
    <div>
      <Navbar
        home="null"
        voting="null"
        gallery="null"
        sponsorship="sponsorship"
        about="null"
        contact="null"
      />
      <LandingSponsorship />
      <ReachNewAudienceSectionSponsorship />
      <SponsorshipBenefitsSection />
      <SponsorshipOffers />
      <SponsorshipGalaExposure />
      <SponsorshipRequest />
      <Footer />
    </div>
  );
};
export default Sponsorship;
